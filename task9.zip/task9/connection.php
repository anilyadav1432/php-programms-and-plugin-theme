<?php
  $con=mysqli_connect("localhost","root","","ced") or die("connection Error");
?>