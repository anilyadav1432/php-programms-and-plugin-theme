<?php

/**
 * Fired during plugin activation
 *
 * @link       cedcoss
 * @since      1.0.0
 *
 * @package    Hide_price_until_login
 * @subpackage Hide_price_until_login/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Hide_price_until_login
 * @subpackage Hide_price_until_login/includes
 * @author     cedcommerce <cedcoss@gmail.com>
 */
class Hide_price_until_login_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
