<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       cedcoss
 * @since      1.0.0
 *
 * @package    Hide_price_until_login
 * @subpackage Hide_price_until_login/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Hide_price_until_login
 * @subpackage Hide_price_until_login/public
 * @author     cedcommerce <cedcoss@gmail.com>
 */
class Hide_price_until_login_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Hide_price_until_login_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Hide_price_until_login_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/hide_price_until_login-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Hide_price_until_login_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Hide_price_until_login_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/hide_price_until_login-public.js', array( 'jquery' ), $this->version, false );

	}

/**
 * hide price on shop,single page if user not match to granted user 
 * @param	int $price	 product price data in this variable
 * @param	int $product product details
**/	 
	function woocommerce_template_loop_price_fun( $price, $product ) {
		$current_user = wp_get_current_user();
		// print_r(get_option( 'price_by_user_set' ));
		if(get_option( 'allow_setting_price_check' ) == "on" && get_option( 'price_by_user_set' ) == ucfirst($current_user->user_login))
		{
			return $price;
		}
		elseif(!empty($current_user->user_login)){
			return $price;
		}
		else{
			// if ( ! is_admin() ) 
			$price = '';
			return $price;
		}
		
	}
	/**
	 * hide price on cart,checkout,order page if user not match to granted user 
	 * @param	int $price	 product price data in this variable
	 * @param	int $product product details
	**/	
	function cart_price_visibility_fun( $price ){

		$current_user = wp_get_current_user();

		if(get_option( 'allow_setting_price_check' ) == "on" && get_option( 'price_by_user_set' ) == ucfirst($current_user->user_login))
		{
			return $price;
		}
		elseif(!empty($current_user->user_login)){
			return $price;
		}
		else{
			// if ( ! is_admin() ) 
			$price = '';
			return $price;
		}
	}

}
