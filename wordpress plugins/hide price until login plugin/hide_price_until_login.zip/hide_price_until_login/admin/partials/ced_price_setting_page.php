
<?php
if(isset($_POST['submit'])){
    $allow_check = $_POST['allow_price_check'];
    $for_user = $_POST['users_name'];
    // echo $for_user;die;
    $deprecated = null;
    $autoload = 'no';
    if ( get_option( 'allow_setting_price_check' ) !== false) {       
        update_option( "allow_setting_price_check", $allow_check );
    }else{
        add_option( "allow_setting_price_check", $allow_check, $deprecated, $autoload );
    }
    if ( get_option( 'price_by_user_set' ) !== false) {       
        update_option( "price_by_user_set", $for_user );
    }else{
        add_option( "price_by_user_set", $for_user, $deprecated, $autoload );
    }
}


$users_arr=array();
global $wp_roles;
$users = $wp_roles->get_names();
// echo "<pre>";print_r($users);
?>

<div>
    <h1 style="text-align:center">untill Login Price Setting Page</h1>
    <form action="" method="post" style="width:50%;margin:auto;">
        <label for="allow_price_check">Enable / Desable</label><br/>
        <input type="checkbox" name="allow_price_check" id="allow_price_check" <?php echo get_option( 'allow_setting_price_check' )=="on"?'checked':'';?>><br/>
        <hr/>
        <label for="users_name">Select User</label><br/>
        <select name="users_name" id="users_name" >
        <?php
        foreach($users as $user){
            if($user == 'Administrator'){
                $user = 'Admin';
            }
            ?>
            
            <option value="<?php echo $user; ?>" <?php echo get_option( 'price_by_user_set' )==$user?'selected':'';?>><?php echo $user; ?></option>
            <?php
        }
        ?>
        </select><br/><br/>
        <input type="submit" value="Save Data" name="submit">
    </form>
    
</div>
