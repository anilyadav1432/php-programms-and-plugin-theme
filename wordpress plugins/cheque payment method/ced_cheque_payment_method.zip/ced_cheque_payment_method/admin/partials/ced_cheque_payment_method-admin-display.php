<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       ced_cheque_payment_method
 * @since      1.0.0
 *
 * @package    Ced_cheque_payment_method
 * @subpackage Ced_cheque_payment_method/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
