<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       ced_cheque_payment_method
 * @since      1.0.0
 *
 * @package    Ced_cheque_payment_method
 * @subpackage Ced_cheque_payment_method/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Ced_cheque_payment_method
 * @subpackage Ced_cheque_payment_method/includes
 * @author     cedcoss <cedcoss@gmail.com>
 */
class Ced_cheque_payment_method_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'ced_cheque_payment_method',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
