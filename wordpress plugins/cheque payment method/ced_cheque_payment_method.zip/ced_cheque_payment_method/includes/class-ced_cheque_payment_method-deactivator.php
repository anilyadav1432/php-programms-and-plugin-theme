<?php

/**
 * Fired during plugin deactivation
 *
 * @link       ced_cheque_payment_method
 * @since      1.0.0
 *
 * @package    Ced_cheque_payment_method
 * @subpackage Ced_cheque_payment_method/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Ced_cheque_payment_method
 * @subpackage Ced_cheque_payment_method/includes
 * @author     cedcoss <cedcoss@gmail.com>
 */
class Ced_cheque_payment_method_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
