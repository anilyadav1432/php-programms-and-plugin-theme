<?php

?>

<h1>Order Importer</h1>
<form action="" method="post" enctype="multipart/form-data">
    <input type="file" name="json_file_data" id="">
    <input type="submit" name="importer_order" value="import json">
</form>

<?php
if( isset($_POST['importer_order']) ){
    $json_file  = $_FILES['json_file_data']['name'];
    $tmpName    = $_FILES['json_file_data']['tmp_name'];
    if(!empty($json_file) && !empty($tmpName)){
        // echo $tmpName;
        $upload = wp_upload_dir();
        // print_r($upload); die();
        $avatar_dir = $upload['basedir'];
        $filestore=$avatar_dir.'/'.$json_file;

        move_uploaded_file($tmpName,$filestore);
        if ( get_option( 'order_file_url' ) !== false) {       
            update_option( "order_file_url", $filestore );
        }else{
            $deprecated = null;
            $autoload = 'no';
            add_option( "order_file_url", $filestore, $deprecated, $autoload );
        }
        
    }
}
// Read JSON file
$file_path=get_option( 'order_file_url' );
if(!empty($file_path))
{
    $json = file_get_contents($file_path);
    //Decode JSON
    $json_data = json_decode($json,true);
    //Print data
    // echo "<pre>";print_r($json_data);
}
?>

<!-- ****************start variable product list import from json file code**************  -->

<?php


/**
 * creating 'WP_LIST_TABLE' for listing variation data from 'Aliexpress Json'
 */

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}   
class OrderTableList extends WP_List_Table{

    public function prepare_items(){
        global $wpdb;
        $arr=array();
        $file_path=get_option( 'order_file_url' );
        $json = file_get_contents($file_path);
        $json_data = json_decode($json,true);
        foreach($json_data['response_data']['list']['elements']['order'] as $ord_val){
            // $order = wc_get_order( $ord_val['purchaseOrderId'] );
            $arr[]=array("purchaseOrderId" => $ord_val['purchaseOrderId'], "customerOrderId" => $ord_val['customerOrderId'], "customerEmailId" => $ord_val['customerEmailId']);
            
        }
        //Print data
        // echo "<pre>";print_r($json_data);
        $this->items = $arr;
        $columns=$this->get_columns(); //getting columns
        // $sortable=$this->get_sortable_columns(); //sorting columns
        $this->_column_headers =array($columns,array());

        /* pagination */
        $per_page = 5;
        $current_page = $this->get_pagenum();
        $total_items = count($this->items);

        $this->items = array_slice($this->items, (($current_page - 1) * $per_page), $per_page);

        $this->set_pagination_args(array(
                'total_items' => $total_items, // total number of items
                'per_page'    => $per_page // items to show on a page
        ));

    }
    public function get_columns(){
        $columns = array(
            'cb'		   => '<input type="checkbox" />', // to display the checkbox.	
            "purchaseOrderId"     =>"Purchase Order Id",
            "customerOrderId" =>"Customer Order ID",
            "customerEmailId"      =>"Customer Email",
            "action"=>"Action",
        );
        return $columns;
    }
    function column_cb($items) {
        return sprintf(
                '<label class="screen-reader-text" for="order_' . $items['purchaseOrderId'] . '">' . sprintf( __( 'Select %s' ), $items['purchaseOrderId'] ) . '</label>'
                . "<input type='checkbox' name='order[]' id='order_{$items['purchaseOrderId']}' value='{$items['purchaseOrderId']}' />"					
        );    
    }
    //column_default
    public function column_default($items,$column_name){
        switch($column_name){
            case 'purchaseOrderId':
            case 'customerOrderId':
            case 'customerEmailId':
                return $items[$column_name];
            case 'action':
                return '<a href="?page='.$_GET['page'].'&action=order-import&order_id='.$items['purchaseOrderId'].'">Import</a>';
            default:
                return "no value";
        }
    }

}

function order_show_list_table(){
    $owt_table = new OrderTableList();
    //calling prepare items from class
  
    $owt_table->prepare_items();
    $owt_table->data=$arr;
    
    $owt_table->display();   
}

order_show_list_table();
?>


<?php

//importing Order after click import button 
$action = isset($_GET['action'])?trim($_GET['action']):"";

if($action == "order-import"){
    $get_order_id=isset($_GET['order_id'])?intval($_GET['order_id']):"";
    foreach($json_data['response_data']['list']['elements']['order'] as $ord_val){
        if($get_order_id == $ord_val['purchaseOrderId']){
            /* First need address */
            $orderAddress = array(
                'first_name' => $ord_val['shippingInfo']['postalAddress']['name'], //add first name to order address
                'last_name'  => '', //add first name to order address
                'company'    => '', //add company name to order address
                'email'      => $ord_val['customerEmailId'], //add email to order address
                'phone'      => $ord_val['shippingInfo']['phone'], //add phone to order address
                'address_1'  => $ord_val['shippingInfo']['postalAddress']['address1'], //add address to order address
                'address_2'  => $ord_val['shippingInfo']['postalAddress']['address2'],
                'city'       => $ord_val['shippingInfo']['postalAddress']['city'], //add city to order address
                'state'      => $ord_val['shippingInfo']['postalAddress']['state'], //add state to order address
                'postcode'   => $ord_val['shippingInfo']['postalAddress']['postalCode'], //add postcode to order address
                'country'    => $ord_val['shippingInfo']['postalAddress']['country'], //add country to order address
            );
            $country = $ord_val['shippingInfo']['postalAddress']['country'];
            // $state   = $ord_val['shippingInfo']['postalAddress']['state'];

            $cutomOrder = wc_create_order(); // create new object for order
            $cutomOrder->set_address( $orderAddress, 'billing' ); // set billing address
            $cutomOrder->set_address( $orderAddress, 'shipping' ); // set shipping address
            // $cutomOrder->set_total( 90 );
            
            $ship_count=1;
            $tax_count=1;
            
            $tax_amt = 0;
            $ship_amt = 0;
            foreach($ord_val['orderLines']['orderLine'] as $key=>$sku_product){
                $pro_amt = 0;
                global $wpdb;
                $product_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value='%s' LIMIT 1", $sku_product['item']['sku'] ) );
                $_product = wc_get_product( $product_id );
                if(!empty($sku_product['item']['sku']))
                {
                    
                    if ($product_id ) {
                      
                        foreach($sku_product['charges']['charge'] as $pro_data){
                            if($pro_data['chargeType'] == 'PRODUCT'){
                                $pro_amt = $pro_amt + $pro_data['chargeAmount']['amount'];
                                $_product->set_price($pro_amt );
                            }
                            if(!empty($pro_data['tax']['taxAmount']['amount']))
                            {
                                $tax_amt = $tax_amt+$pro_data['tax']['taxAmount']['amount'];
                            }    
                            
                            if($pro_data['chargeType'] == 'SHIPPING')
                            {
                                $ship_amt = $ship_amt + $pro_data['chargeAmount']['amount'];
                            }
                            
                        }
                    }
                }
            }
            

            foreach($ord_val['orderLines']['orderLine'] as $key=>$sku_product1){
                /**For add shipping rate */
                if($ship_amt > 0){  
                    if($ship_count == 1){
                        $shipping_tax = array(); 
                        $shipping_rate = new WC_Shipping_Rate( '', $shipping_name, $ship_amt, $shipping_tax, '' );
                        $cutomOrder->add_shipping($shipping_rate);
                    }   
                    $ship_count++;
                }
            
                /**For custom fees Tax rate add */
                if($tax_amt > 0  && $tax_count == 1  )
                {
                    $item_fee = new WC_Order_Item_Fee();
                    $calculate_tax_for = array(
                        'country' => $country, 
                        'state' => '', 
                        'postcode' => '', 
                        'city' => ''
                    );
                    $item_fee->set_name( "Tax" ); // Generic fee name
                    $item_fee->set_amount( $tax_amt ); // Fee amount
                    $item_fee->set_tax_class( '' ); // default for ''
                    $item_fee->set_tax_status( 'taxable' ); // or 'none'
                    $item_fee->set_total( $tax_amt ); // Fee amount
                    // // Calculating Fee taxes
                    $item_fee->calculate_taxes( $calculate_tax_for );
                    // Add Fee item to the order
                    $cutomOrder->add_item( $item_fee );

                    $tax_count++;
                }
                
                
                $cutomOrder->add_product( $_product, 1 );
            }
  
            $cutomOrder->calculate_totals(false); // calculate total
            // update_post_meta( $cutomOrder->id, '_payment_method', 'cod' ); //set payment method
            // update_post_meta( $cutomOrder->id, '_payment_method_title', 'cod' ); //set payment title
            
        }
    }

}

?>