<?php
/**
 * Single Product title
 *
 * This template is Overriding The Core Template File pf Woocoomerce "template/single-product/title.php"
 *
 * @link              https://cedcoss.com/
 * @since             1.0.0
 * @package           Ced_Shopuimodifier
 * @version    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// the_title( '<h3 class="product_title entry-title"> Custom ', '</h3>' );


/**
 * hook and function for change position of title
 */
add_action('woocommerce_before_add_to_cart_form','ced_titile_position',10);
function ced_titile_position(){
	the_title( '<h3 class="product_title entry-title"> Override title  with position change ', '</h3>' );
}