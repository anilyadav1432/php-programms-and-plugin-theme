<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       ced_product_single_page_override
 * @since      1.0.0
 *
 * @package    Ced_product_single_page_override
 * @subpackage Ced_product_single_page_override/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Ced_product_single_page_override
 * @subpackage Ced_product_single_page_override/public
 * @author     cedcoss <cedcoss@gmail.com>
 */
class Ced_product_single_page_override_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Ced_product_single_page_override_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Ced_product_single_page_override_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/ced_product_single_page_override-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Ced_product_single_page_override_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Ced_product_single_page_override_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/ced_product_single_page_override-public.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 *  Function :ced_override_title_singlePage
	 *
	 * @return void
	 * Version:1.0.0
	 * Since:1.0.0
	 * @param $template
	 * @var $template 
	 * @return void
	 */
	public function ced_override_title_singlePage($template)
	{
		if ('title.php' === basename($template)) {
			$template = PLUGIN_DIRPATH . 'woocommerce/single-product/title.php';
		}
		return $template;
	}
	/**
	 *  Function :remove_gallery_thumbnail_images
	 *
	 * @return void
	 * Version:1.0.0
	 * Since:1.0.0
	
	 */
	function remove_gallery_thumbnail_images() {
	if ( is_product() ) {
		remove_action( 'woocommerce_product_thumbnails', 'woocommerce_show_product_thumbnails', 20 );
		}
	}
	/**
	 *  Function :remove_gallery_thumbnail_images - override price prodcut single page
	 *
	 * @return void
	 * Version:1.0.0
	 * Since:1.0.0
	
	 */
	function ced_alter_price_display( $price_html, $product ) {
    
		// ONLY ON FRONTEND
		// if ( is_admin() ) return $price_html;
		
		// ONLY IF PRICE NOT NULL
		// if ( '' === $product->get_price() ) return $price_html;
		
		// IF CUSTOMER LOGGED IN, APPLY 20% DISCOUNT   
		// if ( wc_current_user_has_role( 'customer' ) ) {
			$orig_price = wc_get_price_to_display( $product );
			$price_html = wc_price( $orig_price * 0.80 );
		// }
		
		return $price_html;
	 
	}

	/**
	 * override  description from single product
	 */
	function ced_output_product_data_tabs($template) {
		if ('tabs.php' === basename($template)) {
			$template = PLUGIN_DIRPATH . 'woocommerce/single-product/tabs/tabs.php';
		}
		return $template;
		
	}

/**
 * override short description from single product
 */
	function ced_template_single_excerpt($template){
		if ('short-description.php' === basename($template)) {
			$template = PLUGIN_DIRPATH . 'woocommerce/single-product/short-description.php';
		}
		return $template;
	}

}
