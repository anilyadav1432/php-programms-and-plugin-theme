<?php

/**
 * Fired during plugin activation
 *
 * @link       ced_product_single_page_override
 * @since      1.0.0
 *
 * @package    Ced_product_single_page_override
 * @subpackage Ced_product_single_page_override/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Ced_product_single_page_override
 * @subpackage Ced_product_single_page_override/includes
 * @author     cedcoss <cedcoss@gmail.com>
 */
class Ced_product_single_page_override_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
