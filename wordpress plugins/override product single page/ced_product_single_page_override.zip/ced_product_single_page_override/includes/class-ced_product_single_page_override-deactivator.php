<?php

/**
 * Fired during plugin deactivation
 *
 * @link       ced_product_single_page_override
 * @since      1.0.0
 *
 * @package    Ced_product_single_page_override
 * @subpackage Ced_product_single_page_override/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Ced_product_single_page_override
 * @subpackage Ced_product_single_page_override/includes
 * @author     cedcoss <cedcoss@gmail.com>
 */
class Ced_product_single_page_override_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
