<?php
include('connection.php');
if(!empty($_REQUEST['id'])){
    
    $q="select * from products where id='{$_REQUEST['id']}'";
    $res=mysqli_query($con,$q);
    

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Index</title>
  </head>
  <body>
    <div class="container">
        <div class="row">
            <h1>Description And Time </h1>
            <?php
                if($res->num_rows>0){
                    while($row=mysqli_fetch_assoc($res)){
                        $dayArr=explode(" ",$row['create_at']);
            ?>
                    <p><?php  echo $row['description']; ?></p>
                    <p><?php  echo "add date ".$dayArr[0]; ?></p>
                    <p><?php  echo "Add Time ".$dayArr[1]; ?></p>

            <?php
           
                }
            }
        }
            ?>
        </div>
    </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>