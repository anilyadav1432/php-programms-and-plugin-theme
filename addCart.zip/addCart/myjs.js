var i=1;
var arr=[];
function myfun(id){
    if(!arr.includes(id))
    {
        arr.push(id);
        var val=document.querySelector("#showData");
        val.innerHTML=arr.length;
        document.querySelector("#appendData").innerHTML=`<a href="ShowDetails.php?id=${arr}" class="btn btn-primary">Cart Details</a>`;
    }else{
        alert("already Added");
    }
}